# PlayZone PWA starter

## What's included
- `index.html`: the responsive game app
- `manifest.json`: installable web app metadata
- `sw.js`: basic offline app-shell caching
- `icons/`: app icons

## Preview locally
For a quick preview, open `index.html` in a browser. Some install/offline features require HTTP(S), not `file://`.

## Publish online
1. Upload the contents of this folder to a static hosting service that provides HTTPS.
2. Keep `index.html`, `manifest.json`, `sw.js`, and the `icons` folder together at the same site path.
3. Open the HTTPS site on your phone/tablet and test all games.
4. On supported browsers use the install prompt/menu. On iPhone/iPad, open the site in Safari, tap Share, then Add to Home Screen.

## Before an app-store release
This is a PWA starter, not an App Store or Google Play submission. Store releases usually need a native wrapper/build process, developer accounts, store assets, privacy disclosures, and review. Test on real devices before publishing.
